
# Anxiety SOS (Vite + React + TS)

Proyecto listo para `npm i && npm run dev`.

## Comandos

```bash
npm i
npm run dev
# luego abre el URL impreso (p.ej. http://localhost:5173/)
```

```bash
npm run build
npm run preview
```
