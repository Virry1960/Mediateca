import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useReducer,
  FC,
} from "react";

/* -------------------- Config & Types -------------------- */

const AFFIRMATIONS_NO = [
  "Jeg er trygg i dette øyeblikket",
  "Dette er bare en tanke",
  "Det skjer ikke nå",
  "Jeg kan føle bakken under føttene mine og jeg er her og nå",
  "Jeg liker å rette oppmerksomheten min mot ting jeg liker",
  "Oppmerksomheten min gjør det jeg vil",
];

type StepType =
  | "scale"
  | "defusion"
  | "g54321"
  | "simpleWrite"
  | "grounding"
  | "breathing"
  | "values"
  | "plan";

interface BaseStep {
  id: string;
  type: StepType;
  key: string;
  title?: string;
  helper?: string;
  placeholder?: string;
  extra?: string[];
}

interface ScaleStep extends BaseStep {
  type: "scale";
  min: number;
  max: number;
  def: number;
  labels?: string[];
}
interface DefusionStep extends BaseStep {
  type: "defusion";
}
interface GuideStep extends BaseStep {
  type: "g54321";
}
interface SimpleWriteStep extends BaseStep {
  type: "simpleWrite";
  count: number;
}
interface GroundingStep extends BaseStep {
  type: "grounding";
}
interface BreathingStep extends BaseStep {
  type: "breathing";
  durationSec?: number;
  info?: string;
}
interface ValuesStep extends BaseStep {
  type: "values";
}
interface PlanStep extends BaseStep {
  type: "plan";
}

type Step =
  | ScaleStep
  | DefusionStep
  | GuideStep
  | SimpleWriteStep
  | GroundingStep
  | BreathingStep
  | ValuesStep
  | PlanStep;

const DEFAULT_FLOW: Step[] = [
  {
    id: "A1",
    type: "scale",
    key: "distress",
    title: "Hvor sterk er angsten akkurat nå?",
    helper: "Dra for å markere 0–10",
    labels: ["0", "5", "10"],
    extra: [
      "Skjedde det noe for at jeg skulle føle meg slik?",
      "Hvis det ikke skjer noe rart... det er bare tanker",
      "Med tanker endrer ikke verden seg. Det er ingen grunn til at jeg skal bli redd eller engstelig.",
    ],
    min: 0,
    max: 10,
    def: 7,
  },
  {
    id: "A2",
    type: "defusion",
    key: "mind_says",
    title: "Hva sier tankene?",
    helper:
      "Skriv setningen kort, som en undertekst (‘jeg klarer det ikke’, ‘noe vondt skjer’). Å navngi reduserer trykket.",
    extra: [
      "Mitt tankekjør forstyrrer meg noen ganger bare ved å tenke... 'Hva om...' og da dukker det opp ideer som...",
      "Hvis jeg setter dem i ord, vil de miste styrke (de er bare tanker...)",
    ],
    placeholder: "Tankene sier…",
  },
  { id: "B0", type: "g54321", key: "g54321", title: "Grounding  (guía)", helper: "Jeg leder deg: 5 ting å se, 4 å ta på, 3 å høre, 2 å lukte, 1 å smake." },
  { id: "B1", type: "simpleWrite", key: "see",   title: "Fem ting jeg kan se",   helper: "Skriv fem ting du kan se rundt deg (én linje per ting).", count: 5 },
  { id: "B2", type: "simpleWrite", key: "touch", title: "Fire ting jeg kan ta på", helper: "Skriv fire ting du kan ta på (én linje per ting).", count: 4 },
  { id: "B3", type: "simpleWrite", key: "hear",  title: "Tre ting jeg kan høre",  helper: "Skriv tre ting du kan høre (én linje per ting).",         count: 3 },
  { id: "B4", type: "simpleWrite", key: "smell", title: "To ting jeg kan lukte", helper: "Skriv to ting du kan lukte (én linje per ting).",          count: 2 },
  { id: "B5", type: "simpleWrite", key: "taste", title: "Én ting jeg kan smake", helper: "Skriv én ting du kan smake (én linje per ting).",          count: 1 },
  { id: "C1", type: "grounding", key: "grounding", title: "Grounding affirmasjoner", helper: "Trykk på knappene for å minne deg selv på det som hjelper." },
  {
    id: "A4",
    type: "breathing",
    key: "breath",
    title: "Pust inn 4, ut 6. Følg sirkelen.",
    helper: "Du kan repetere det så mange ganger du trenger.",
    info: "Den langsomme og dype pusten hjelper meg å slappe av.",
    durationSec: 120,
  },
  {
    id: "A5",
    type: "values",
    key: "values",
    title: "Et lite steg med mening",
    helper:
      "Velg en mikrohandling på 2–5 minutter i tråd med verdiene dine...",
    placeholder: "Mitt lille steg blir…",
  },
  {
    id: "A6",
    type: "plan",
    key: "plan",
    title: "Plan nå (neste 10–30 min)",
    helper:
      "Bestem hvor, når og hvordan. Gjenta pust/grounding om uroen øker...",
    placeholder: "Jeg gjør dette, på dette stedet, kl…",
  },
];

/* -------------------- Hooks -------------------- */

function useLocalStorage<T>(key: string, initial: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [val, setVal] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch {}
  }, [key, val]);

  return [val, setVal];
}

// ---- Speech handling ----
declare global {
  interface Window {
    __spokenKeys?: Set<string>;
  }
}

interface SpeechItem {
  text: string;
  rate?: number;
  pitch?: number;
  delayMs?: number;
}

const PAUSE_MS = 1000;
const SHORT_PAUSE_MS = 500;

function speakSequence(items: SpeechItem[]) {
  if (!("speechSynthesis" in window)) return;

  const speakNext = (idx: number) => {
    if (idx >= items.length) return;
    const item = items[idx];
    const u = new SpeechSynthesisUtterance(item.text);
    u.rate = item.rate ?? 0.7;
    u.pitch = item.pitch ?? 0.7;
    u.lang = "nb-NO";
    u.onend = () => {
      setTimeout(() => speakNext(idx + 1), item.delayMs ?? 0);
    };

    const voices = window.speechSynthesis.getVoices();
    const noVoice = voices.find(
      (v) =>
        (v.lang || "").toLowerCase().startsWith("nb") ||
        (v.lang || "").toLowerCase().startsWith("no")
    );
    if (noVoice) u.voice = noVoice;
    window.speechSynthesis.speak(u);
  };

  speakNext(0);
}

function useSpeech() {
  const speakTextOnce = useCallback((text: string, key: string, rate = 0.6, pitch = 0.75) => {
    if (!("speechSynthesis" in window)) return;
    window.__spokenKeys = window.__spokenKeys || new Set<string>();
    if (window.__spokenKeys.has(key)) return;
    window.__spokenKeys.add(key);

    const u = new SpeechSynthesisUtterance(text);
    u.rate = rate;
    u.pitch = pitch;
    u.lang = "nb-NO";

    const assignVoice = () => {
      const voices = window.speechSynthesis.getVoices();
      const noVoice = voices.find(
        (v) =>
          (v.lang || "").toLowerCase().startsWith("nb") ||
          (v.lang || "").toLowerCase().startsWith("no")
      );
      if (noVoice) u.voice = noVoice;
      window.speechSynthesis.speak(u);
    };

    if (window.speechSynthesis.getVoices().length === 0) {
      const once = () => {
        window.speechSynthesis.onvoiceschanged = null;
        assignVoice();
      };
      window.speechSynthesis.onvoiceschanged = once;
      setTimeout(assignVoice, 400);
    } else {
      assignVoice();
    }
  }, []);

  const speakNow = useCallback(
    (text: string) => speakTextOnce(text, "now_" + Date.now()),
    [speakTextOnce]
  );

  const stopSpeech = useCallback((clearKeys = false) => {
    try {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    } catch {}
    if (clearKeys) {
      try {
        if (window.__spokenKeys && typeof window.__spokenKeys.clear === "function") {
          window.__spokenKeys.clear();
        } else {
          window.__spokenKeys = new Set<string>();
        }
      } catch {}
    }
  }, []);

  return { speakTextOnce, speakSequence, speakNow, stopSpeech };
}

/* -------------------- Reducer -------------------- */

interface AnswersState {
  idx: number;
  values: Record<string, any>;
}

type Action =
  | { type: "SET_VALUE"; key: string; value: any }
  | { type: "NEXT" }
  | { type: "BACK" }
  | { type: "RESET" };

function answersReducer(state: AnswersState, action: Action): AnswersState {
  switch (action.type) {
    case "SET_VALUE":
      return {
        ...state,
        values: { ...state.values, [action.key]: action.value },
      };
    case "NEXT":
      return { ...state, idx: state.idx + 1 };
    case "BACK":
      return { ...state, idx: Math.max(state.idx - 1, 0) };
    case "RESET":
      return { idx: 0, values: {} };
    default:
      return state;
  }
}

/* -------------------- UI Components -------------------- */

type BreathCircleProps = { running: boolean; durationSec?: number; onComplete?: () => void };

const BreathCircle: FC<BreathCircleProps> = ({ running, durationSec = 120, onComplete }) => {
  const [t, setT] = useState(0);
  const raf = useRef<number>(0 as unknown as number);
  const startRef = useRef<number>(0);

  const anim = (ts: number) => {
    if (!startRef.current) startRef.current = ts;
    const elapsed = (ts - startRef.current) / 1000;
    setT(elapsed);
    if (elapsed >= durationSec) {
      cancelAnimationFrame(raf.current);
      onComplete && onComplete();
      return;
    }
    raf.current = requestAnimationFrame(anim);
  };

  useEffect(() => {
    if (running) {
      startRef.current = 0;
      raf.current = requestAnimationFrame(anim);
    } else {
      cancelAnimationFrame(raf.current);
    }
    return () => cancelAnimationFrame(raf.current);
  }, [running, durationSec]);

  const cycle = 10;
  const phaseT = t % cycle;
  const inhale = phaseT < 4;
  const r = inhale ? 40 + (phaseT / 4) * 30 : 70 - ((phaseT - 4) / 6) * 30;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
      <div style={{ fontSize: 12, color: "#64748b" }}>{inhale ? "Pust inn" : "Pust ut"}</div>
      <svg viewBox="0 0 220 220" style={{ width: 220, height: 220, color: "#2563eb" }}>
        <circle cx="110" cy="110" r={r} fill="currentColor" style={{ opacity: 0.2 }} />
        <circle cx="110" cy="110" r={Math.max(0, r - 2)} fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>
      <div style={{ fontSize: 12, color: "#64748b" }}>{Math.max(0, Math.ceil(durationSec - t))}s</div>
    </div>
  );
};

/* ---------- Individual Step Views ---------- */

const ScaleStepView: FC<{
  step: ScaleStep;
  value: number | undefined;
  setValue: (n: number) => void;
  speakTextOnce: (text: string, key: string) => void;
}> = ({ step, value, setValue, speakTextOnce }) => (
  <div>
    <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
    <input
      type="range"
      min={step.min}
      max={step.max}
      step={1}
      value={typeof value === "number" ? value : step.def}
      onChange={(e) => {
        const v = Number((e.target as HTMLInputElement).value);
        setValue(v);
        if (step.extra) speakTextOnce(step.extra.join(". "), step.id);
      }}
      style={{ width: "100%" }}
    />
    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#64748b", marginTop: 4 }}>
      <span>0</span><span>5</span><span>10</span>
    </div>
    {step.extra?.map((line, i) => (
      <div key={i} style={{ fontSize: 12, color: "#64748b", marginTop: 6 }}>{line}</div>
    ))}
  </div>
);

const DefusionStepView: FC<{
  step: DefusionStep;
  value: string | undefined;
  setValue: (s: string) => void;
}> = ({ step, value, setValue }) => (
  <div>
    <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
    {step.extra?.map((line, i) => (
      <div key={i} style={{ fontSize: 12, color: "#64748b", marginTop: 6 }}>{line}</div>
    ))}
    <textarea
      placeholder={step.placeholder}
      value={value || ""}
      onChange={(e) => setValue(e.target.value)}
      style={{ width: "100%", minHeight: 72, border: "1px solid #e2e8f0", borderRadius: 12, padding: "8px 10px" }}
    />
  </div>
);

const GuideStepView: FC<{
  step: GuideStep;
  goNext: () => void;
  speakTextOnce: (text: string, key: string) => void;
}> = ({ step, goNext, speakTextOnce }) => {
  useEffect(() => {
    const intro =
      "Vi skal gjøre øvelsen 5, 4, 3, 2, 1. Først ser du deg rundt og finner fem ting du kan SE. Så fire ting du kan TA PÅ. Deretter tre ting du kan HØRE. Etter det to ting du kan LUKTE. Og til slutt én ting du kan SMAKE.";
    speakTextOnce(intro, step.id + "_intro");
  }, [step, speakTextOnce]);

  const play = (txt: string, k: string) => speakTextOnce(txt, step.id + "_" + k + "_" + Date.now());

  return (
    <div>
      <div style={{ fontSize: 13, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <button onClick={() => play("Se deg rundt og nevn fem ting du kan se.", "see")} style={{ padding: "8px 10px", borderRadius: 10, border: "1px solid #e2e8f0" }}>5 – Se</button>
        <button onClick={() => play("Finn fire ting du kan ta på og kjenn teksturen.", "touch")} style={{ padding: "8px 10px", borderRadius: 10, border: "1px solid #e2e8f0" }}>4 – Ta på</button>
        <button onClick={() => play("Lytt etter tre lyder, både nære og fjerne.", "hear")} style={{ padding: "8px 10px", borderRadius: 10, border: "1px solid #e2e8f0" }}>3 – Hør</button>
        <button onClick={() => play("Legg merke til to ting du kan lukte.", "smell")} style={{ padding: "8px 10px", borderRadius: 10, border: "1px solid #e2e8f0" }}>2 – Lukt</button>
        <button onClick={() => play("Prøv å legge merke til én ting du kan smake.", "taste")} style={{ padding: "8px 10px", borderRadius: 10, border: "1px solid #e2e8f0" }}>1 – Smak</button>
      </div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 12 }}>
        <button onClick={goNext} style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid #e2e8f0" }}>Neste</button>
      </div>
    </div>
  );
};

const SimpleWriteStepView: FC<{
  step: SimpleWriteStep;
  value: string | undefined;
  setValue: (s: string) => void;
  goNext: () => void;
  speakTextOnce: (text: string, key: string) => void;
}> = ({ step, value, setValue, goNext, speakTextOnce }) => {
  useEffect(() => {
    speakTextOnce(`${step.title}. ${step.helper}`, step.id);
  }, [step, speakTextOnce]);

  const max = step.count;

  const splitLines = (text: string) => (text || "").replace(/\r/g, "").split("\n");
  const nonEmptyCount = (text: string) => splitLines(text).map((v) => v.trim()).filter(Boolean).length;
  const limitByMaxLines = (text: string) => splitLines(text).slice(0, max).join("\n");

  const countFilled = value ? nonEmptyCount(value) : 0;

  return (
    <div>
      <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
      <textarea
        value={value || ""}
        placeholder={Array.from({ length: max }, (_, i) => `${i + 1}.`).join("\n")}
        onChange={(e) => {
          const limited = limitByMaxLines(e.target.value);
          setValue(limited);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            const currentVal = e.currentTarget.value || "";
            const total = splitLines(currentVal).length;
            const filled = nonEmptyCount(currentVal);
            if (total >= max) {
              e.preventDefault();
              if (filled >= max) {
                speakTextOnce("Fint. Vi går videre.", `${step.id}_next_${Date.now()}`);
                goNext();
              }
            }
          }
        }}
        style={{ width: "100%", minHeight: Math.max(72, max * 22), border: "1px solid #e2e8f0", borderRadius: 12, padding: "8px 10px" }}
      />
      <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 6 }}>{countFilled}/{max}</div>
    </div>
  );
};

const GroundingStepView: FC<{
  value: string | undefined;
  setValue: (s: string) => void;
  speakNow: (text: string) => void;
}> = ({ value, setValue, speakNow }) => (
  <div>
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
      {AFFIRMATIONS_NO.map((a) => (
        <button
          key={a}
          onClick={() => {
            setValue(((value || "").trim() ? value + "\n" : "") + a);
            speakNow(a);
          }}
          style={{ fontSize: 13, padding: "6px 10px", borderRadius: 999, border: "1px solid #e2e8f0", background: "#f8fafc", cursor: "pointer" }}
        >
          {a}
        </button>
      ))}
    </div>
    {value && value.trim() ? (
      <pre style={{ whiteSpace: "pre-wrap", fontSize: 13, color: "#1f2937", border: "1px solid #e2e8f0", borderRadius: 12, padding: "8px 10px", background: "#f8fafc" }}>{value}</pre>
    ) : null}
  </div>
);

const BreathingStepView: FC<{
  step: BreathingStep;
  running: boolean;
  onStart: () => void;
}> = ({ step, running, onStart }) => (
  <div>
    <h3 style={{ marginBottom: 4 }}>{step.title}</h3>
    <div style={{ fontSize: 14, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
    <div style={{ display: "flex", justifyContent: "center" }}>
      <BreathCircle running={running} durationSec={step.durationSec} />
    </div>
    {step.info && <div style={{ fontSize: 12, color: "#64748b", textAlign: "center", marginTop: 6 }}>{step.info}</div>}
    <div style={{ display: "flex", justifyContent: "center", marginTop: 8 }}>
      <button onClick={onStart} style={{ padding: "8px 12px", border: "1px solid #e2e8f0", borderRadius: 10 }}>{running ? "Restart" : "Start"}</button>
    </div>
  </div>
);

const ValuesStepView: FC<{ step: ValuesStep; value: string | undefined; setValue: (s: string) => void }> = ({ step, value, setValue }) => (
  <div>
    <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
    <textarea
      placeholder={step.placeholder}
      value={value || ""}
      onChange={(e) => setValue(e.target.value)}
      style={{ width: "100%", minHeight: 72, border: "1px solid #e2e8f0", borderRadius: 12, padding: "8px 10px" }}
    />
  </div>
);

const PlanStepView: FC<{ step: PlanStep; value: string | undefined; setValue: (s: string) => void }> = ({ step, value, setValue }) => (
  <div>
    <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>{step.helper}</div>
    <textarea
      placeholder={step.placeholder}
      value={value || ""}
      onChange={(e) => setValue(e.target.value)}
      style={{ width: "100%", minHeight: 96, border: "1px solid #e2e8f0", borderRadius: 12, padding: "8px 10px" }}
    />
  </div>
);

/* ---------- Main StepRenderer ---------- */

type StepRendererProps = {
  step: Step;
  value: any;
  setValue: (v: any) => void;
  goNext: () => void;
  running: boolean;
  setRunning: React.Dispatch<React.SetStateAction<boolean>>;
  speech: ReturnType<typeof useSpeech>;
};

const StepRenderer: FC<StepRendererProps> = ({
  step,
  value,
  setValue,
  goNext,
  running,
  setRunning,
  speech,
}) => {
  const { speakTextOnce, speakNow } = speech;

  switch (step.type) {
    case "scale":
      return (
        <ScaleStepView
          step={step}
          value={value}
          setValue={(n) => setValue(n)}
          speakTextOnce={speakTextOnce}
        />
      );
    case "defusion":
      return <DefusionStepView step={step} value={value} setValue={(s) => setValue(s)} />;
    case "g54321":
      return <GuideStepView step={step} goNext={goNext} speakTextOnce={speakTextOnce} />;
    case "simpleWrite":
      return (
        <SimpleWriteStepView
          step={step}
          value={value}
          setValue={(s) => setValue(s)}
          goNext={goNext}
          speakTextOnce={speakTextOnce}
        />
      );
    case "grounding":
      return <GroundingStepView value={value} setValue={(s) => setValue(s)} speakNow={speakNow} />;
    case "breathing":
      return (
        <BreathingStepView
          step={step}
          running={running}
          onStart={() => setRunning((r) => !r)}
        />
      );
    case "values":
      return <ValuesStepView step={step} value={value} setValue={(s) => setValue(s)} />;
    case "plan":
      return <PlanStepView step={step} value={value} setValue={(s) => setValue(s)} />;
    default:
      return null;
  }
};

/* -------------------- App -------------------- */

const App: FC = () => {
  const [answers, dispatch] = useReducer(answersReducer, { idx: 0, values: {} });
  const [running, setRunning] = useState(false);
  const speech = useSpeech();
  const { stopSpeech, speakSequence } = speech;

  const flow = DEFAULT_FLOW;
  const finished = answers.idx >= flow.length;
  const step = flow[Math.min(answers.idx, flow.length - 1)] || flow[0];
  const progress = Math.round((answers.idx / flow.length) * 100);

  const setValue = useCallback((val: any) => {
    dispatch({ type: "SET_VALUE", key: step.key, value: val });
  }, [step.key]);

  const next = useCallback(() => {
    stopSpeech(false);
    dispatch({ type: "NEXT" });
  }, [stopSpeech]);

  const back = useCallback(() => {
    stopSpeech(false);
    dispatch({ type: "BACK" });
  }, [stopSpeech]);

  const reset = useCallback(() => {
    stopSpeech(true);
    try {
      localStorage.removeItem("anxSOS_state_no_pwa_simple");
    } catch {}
    setRunning(false);
    dispatch({ type: "RESET" });
  }, [stopSpeech]);

  useEffect(() => {
    stopSpeech(false);
  }, [step.id, stopSpeech]);

  const [_, setPersisted] = useLocalStorage<AnswersState>("anxSOS_state_no_pwa_simple", answers);
  useEffect(() => {
    setPersisted(answers);
  }, [answers, setPersisted]);

  useEffect(() => {
    if (!finished) return;
    stopSpeech(false);
    const v = answers.values || {};
    const lines: string[] = [];
    const seq: SpeechItem[] = [];

    if (v.mind_says && v.mind_says.trim()) {
      lines.push("- Tankene sier: " + v.mind_says);
      seq.push({ text: "Tankene sier: " + v.mind_says, rate: 0.55, pitch: 0.7, delayMs: PAUSE_MS });
    }

    seq.push({ text: " Her og nå er det dette som omgir meg:", rate: 0.65, pitch: 0.7, delayMs: PAUSE_MS });

    const parseLines = (txt: string) =>
      txt.split("\n").map((s: string) => s.trim()).filter(Boolean);

    const addGroup = (title: string, arr: string[]) => {
      if (!arr.length) return;
      seq.push({ text: title, rate: 0.65, pitch: 0.7, delayMs: PAUSE_MS });
      arr.forEach((item) =>
        seq.push({ text: item, rate: 0.65, pitch: 0.7, delayMs: SHORT_PAUSE_MS })
      );
    };

    addGroup("Dette er tingene jeg ser:", v.see ? parseLines(v.see) : []);
    addGroup("Dette er tingene jeg berører:", v.touch ? parseLines(v.touch) : []);
    addGroup("Dette er tingene jeg hører:", v.hear ? parseLines(v.hear) : []);
    addGroup("Dette er tingene jeg lukter:", v.smell ? parseLines(v.smell) : []);
    addGroup("Dette er det jeg smaker:", v.taste ? parseLines(v.taste) : []);

    seq.push({ text: "Jeg må huske:", rate: 0.65, pitch: 0.7, delayMs: PAUSE_MS });
    const chips = v.grounding ? parseLines(v.grounding) : [];
    chips.forEach((c) =>
      seq.push({ text: c, rate: 0.65, pitch: 0.7, delayMs: SHORT_PAUSE_MS })
    );

    seq.push({ text: "Så planlegger jeg å:", rate: 0.65, pitch: 0.7, delayMs: PAUSE_MS });
    const vals = v.values ? parseLines(v.values) : [];
    vals.forEach((c) =>
      seq.push({ text: c, rate: 0.65, pitch: 0.7, delayMs: SHORT_PAUSE_MS })
    );

    seq.push({ text: "Og jeg skal gjøre det:", rate: 0.65, pitch: 0.7, delayMs: PAUSE_MS });
    const plans = v.plan ? parseLines(v.plan) : [];
    plans.forEach((c) =>
      seq.push({ text: c, rate: 0.65, pitch: 0.7, delayMs: SHORT_PAUSE_MS })
    );

    speakSequence(seq);

    const parts: string[] = [];
    if (v.see && v.see.trim()) parts.push(`5 ting jeg så: ${parseLines(v.see).join("; ")}`);
    if (v.touch && v.touch.trim()) parts.push(`4 ting jeg rørte: ${parseLines(v.touch).join("; ")}`);
    if (v.hear && v.hear.trim()) parts.push(`3 ting jeg hørte: ${parseLines(v.hear).join("; ")}`);
    if (v.smell && v.smell.trim()) parts.push(`2 ting jeg luktet: ${parseLines(v.smell).join("; ")}`);
    if (v.taste && v.taste.trim()) parts.push(`1 ting jeg smakte: ${parseLines(v.taste).join("; ")}`);
    if (parts.length) lines.push("- Grounding:" + parts.join(" | "));
    lines.push("- Jeg må huske: " + (chips.length ? chips.join("; ") : "Grounding kommer her"));
    if (vals.length) lines.push("- Så planlegger jeg å: " + vals.join("; "));
    if (plans.length) lines.push("- Og jeg skal gjøre det: " + plans.join("; "));
  }, [finished, answers.values, speakSequence, stopSpeech]);

  const canProceed = (() => {
    if (!step || step.type !== "simpleWrite") return true;
    const v = answers.values[step.key] || "";
    const count = (v || "").split("\n").map((s: string) => s.trim()).filter(Boolean).length;
    return count >= (step.count || 1);
  })();

  return (
    <div style={{ padding: 16, maxWidth: 720, margin: "0 auto" }}>
      <h2 style={{ margin: 0, fontSize: 18 }}>
        {finished ? "Plan for de neste minuttene" : step.title || `Steg ${answers.idx + 1}`}
      </h2>

      {!finished && (
        <div style={{ height: 8, width: "100%", background: "#e5e7eb", borderRadius: 999, overflow: "hidden", marginTop: 8 }}>
          <div style={{ height: "100%", background: "#2563eb", width: `${progress}%` }} />
        </div>
      )}

      <div style={{ marginTop: 12 }}>
        <StepRenderer
          step={step}
          value={answers.values[step.key]}
          setValue={setValue}
          goNext={next}
          running={running}
          setRunning={setRunning}
          speech={speech}
        />
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
        <button onClick={back} disabled={answers.idx === 0}>Tilbake</button>
        {!finished ? (
          <button onClick={next} disabled={!canProceed}>{answers.idx >= flow.length - 1 ? "Ferdig" : "Neste"}</button>
        ) : (
          <button onClick={reset}>Start på nytt</button>
        )}
      </div>

      {finished && (
        <pre style={{ whiteSpace: "pre-wrap", fontSize: 13, marginTop: 12 }}>
          {(() => {
            const v = answers.values || {};
            const parseLines = (txt: string) =>
              (txt || "").split("\n").map((s) => s.trim()).filter(Boolean);
            const lines: string[] = [];
            if (v.mind_says && v.mind_says.trim()) lines.push("- Tankene sier: " + v.mind_says);
            const parts: string[] = [];
            if (v.see && v.see.trim()) parts.push(`5 ting jeg så: ${parseLines(v.see).join("; ")}`);
            if (v.touch && v.touch.trim()) parts.push(`4 ting jeg rørte: ${parseLines(v.touch).join("; ")}`);
            if (v.hear && v.hear.trim()) parts.push(`3 ting jeg hørte: ${parseLines(v.hear).join("; ")}`);
            if (v.smell && v.smell.trim()) parts.push(`2 ting jeg luktet: ${parseLines(v.smell).join("; ")}`);
            if (v.taste && v.taste.trim()) parts.push(`1 ting jeg smakte: ${parseLines(v.taste).join("; ")}`);
            if (parts.length) lines.push("- Det som virkelig omgir meg er:" + parts.join(" | "));
            const chips = v.grounding ? parseLines(v.grounding) : [];
            lines.push("- Jeg må huske: " + (chips.length ? chips.join("; ") : "Grounding kommer her"));
            const vals = v.values ? parseLines(v.values) : [];
            if (vals.length) lines.push("- Så planlegger jeg å: " + vals.join("; "));
            const plans = v.plan ? parseLines(v.plan) : [];
            if (plans.length) lines.push("- Og jeg skal gjøre det: " + plans.join("; "));
            return lines.join("\n");
          })()}
        </pre>
      )}

      <div style={{ textAlign: "center", fontSize: 11, color: "#64748b", paddingTop: 8 }}>
        Offline, lokal lagring. vNO-2.6-sequence
      </div>
    </div>
  );
};

export default App;
